'use client';

import { useQuery } from '@tanstack/react-query';
import { getMessages } from '@/lib/services/messaging.service';
import type { Message, User } from '@/lib/types';
import { Skeleton } from '@/components/ui/skeleton';
import { MessageItem } from './message-item';
import { useEffect, useRef, useState, useCallback } from 'react';

import { Button } from '@/components/ui/button';
import Loader2 from 'lucide-react/icons/loader-2';

interface MessageListProps {
  conversationId: string;
  messages: Message[];
  currentUser: User;
  fetchNextPage: () => void;
  hasNextPage?: boolean;
  isFetchingNextPage: boolean;
}

// ... (Skeleton component remains the same)

export function MessageList({ conversationId, messages, currentUser, fetchNextPage, hasNextPage, isFetchingNextPage }: MessageListProps) {
    const scrollRef = useRef<HTMLDivElement>(null);
    const [isUserScrollingUp, setIsUserScrollingUp] = useState(false);
    const prevScrollHeight = useRef(0);

    console.log("Messages in MessageList:", messages);

    // Auto-scroll to bottom on initial load or when current user sends a message
    useEffect(() => {
        if (scrollRef.current) {
            scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
        }
    }, []); // Only on initial mount

    useEffect(() => {
        if (scrollRef.current) {
            const { scrollTop, scrollHeight, clientHeight } = scrollRef.current;
            const lastMessage = messages[messages.length - 1];

            // If the last message is from the current user, always scroll to bottom
            // Or if the user is near the bottom (within 100px), auto-scroll
            if (lastMessage?.sender_id === currentUser.id || (scrollHeight - scrollTop - clientHeight < 100 && !isUserScrollingUp)) {
                scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
            }
        }
    }, [messages, currentUser.id, isUserScrollingUp]);

    const handleScroll = useCallback(() => {
        if (scrollRef.current) {
            const { scrollTop, scrollHeight, clientHeight } = scrollRef.current;

            // Detect if user is scrolling up
            if (scrollTop < scrollHeight - clientHeight - 100) { // If not near bottom
                setIsUserScrollingUp(true);
            } else {
                setIsUserScrollingUp(false);
            }

            // Infinite scrolling: load more messages when scrolled to top
            if (scrollTop === 0 && hasNextPage && !isFetchingNextPage) {
                fetchNextPage();
            }
        }
    }, [fetchNextPage, hasNextPage, isFetchingNextPage]);

    // Adjust scroll position to maintain view when new messages are loaded at the top
    useEffect(() => {
        if (scrollRef.current && isFetchingNextPage) {
            const currentScrollHeight = scrollRef.current.scrollHeight;
            const heightDifference = currentScrollHeight - prevScrollHeight.current;
            scrollRef.current.scrollTop += heightDifference;
        }
        prevScrollHeight.current = scrollRef.current?.scrollHeight || 0;
    }, [isFetchingNextPage, messages]);

    return (
        <div ref={scrollRef} onScroll={handleScroll} className="flex-1 p-4 space-y-4 overflow-y-auto flex flex-col-reverse">
            {isFetchingNextPage && (
                <div className="text-center py-2">
                    <Loader2 className="h-5 w-5 animate-spin mx-auto text-muted-foreground" />
                </div>
            )}
            <div className="space-y-4">
                {messages.length > 0 ? (
                    messages.map((msg, index) => {
                        const previousMessage = messages[index + 1]; // Because messages are reversed
                        const isSameSenderAsPrevious = previousMessage && msg.sender_id === previousMessage.sender_id;
                        const isFirstInGroup = !isSameSenderAsPrevious;

                        return (
                            <MessageItem 
                                key={msg.id}
                                message={msg}
                                currentUser={currentUser}
                                isFirstInGroup={isFirstInGroup}
                            />
                        );
                    })
                ) : (
                    <div className="flex h-full items-center justify-center">
                        <p className="text-center text-sm text-muted-foreground">No messages yet. Start the conversation!</p>
                    </div>
                )}
            </div>
            {hasNextPage && !isFetchingNextPage && (
                <div className="text-center py-2">
                    <Button
                        onClick={() => fetchNextPage()}
                        variant="outline"
                        size="sm"
                    >
                        Load More
                    </Button>
                </div>
            )}
        </div>
    );
}
