// frontend/src/hooks/use-messaging.ts
'use client';

import { useMutation, useQuery, useQueryClient, InfiniteData } from '@tanstack/react-query';
import { useToast } from '@/hooks/use-toast';
import * as MessagingService from '@/lib/services/messaging.service';
import type { Message, Conversation } from '@/lib/types';
import { useUser } from '@/context/user-provider';
import { toNullableString } from '@/lib/utils';

export function useSendMessage() {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const { user } = useUser();

  return useMutation({
    mutationFn: ({ conversationId, content, messageType }) => MessagingService.sendMessage(conversationId, content, messageType),

    onMutate: async ({ conversationId, content, messageType = 'text' }: { conversationId: string; content: string; messageType?: "text" | "image" | "file" }) => {
      await queryClient.cancelQueries({ queryKey: ['messages', conversationId] });

      const previousMessages = queryClient.getQueryData<InfiniteData<Message[]>>([
        'messages',
        conversationId,
      ]);

      const optimisticId = `optimistic-${Date.now()}`;
      const optimisticMessage: Message = {
        id: optimisticId,
        conversation_id: conversationId,
        sender_id: user?.id ?? 'current-user',
        content,
        message_type: messageType,
        media_url: null,
        file_metadata: null,
        reply_to_message_id: toNullableString(null),
        mentioned_user_ids: [],
        is_edited: false,
        edited_at: null,
        is_deleted: false,
        deleted_at: null,
        sent_at: new Date().toISOString(),
        created_at: new Date().toISOString(),
        author: user
          ? {
              id: user.id,
              name: user.name,
              profile_picture_url: user.profile_picture_url,
            }
          : undefined,
      };

      queryClient.setQueryData<InfiniteData<Message[]>>(['messages', conversationId], (old) => {
        if (!old) {
          return {
            pageParams: [0],
            pages: [[optimisticMessage]],
          };
        }

        return {
          ...old,
          pages: old.pages.map((page, index) =>
            index === 0 ? [optimisticMessage, ...page] : page
          ),
        };
      });

      // Optimistically update conversation preview
      queryClient.setQueryData<Message | undefined>(
        ['conversation', conversationId],
        (oldConversation: Message | undefined) =>
          oldConversation
            ? {
                ...oldConversation,
                last_message: content,
                last_message_at: new Date().toISOString(),
              }
            : oldConversation
      );

      return { previousMessages, optimisticId, conversationId };
    },

    onSuccess: (newMessage: Message, variables, context) => {
      const enrichedMessage: Message = {
        ...newMessage,
        author:
          newMessage.author ||
          (user
            ? {
                id: user.id,
                name: user.name,
                profile_picture_url: user.profile_picture_url,
              }
            : undefined),
      };

      queryClient.setQueryData<InfiniteData<Message[]>>(
        ['messages', newMessage.conversation_id],
        (old) => {
          if (!old) return old;
          return {
            ...old,
            pages: old.pages.map((page, index) =>
              index === 0
                ? page.map((message) =>
                    message.id === context?.optimisticId ? enrichedMessage : message
                  )
                : page
            ),
          };
        }
      );

      queryClient.setQueryData<Conversation | null>(
        ['conversation', newMessage.conversation_id],
        (oldConversation) =>
          oldConversation
            ? {
                ...oldConversation,
                last_message: enrichedMessage.content,
                last_message_at: enrichedMessage.created_at,
              }
            : oldConversation
      );

      queryClient.setQueryData<Conversation[] | undefined>(
        ['conversations'],
        (oldConversations) =>
          oldConversations
            ? oldConversations.map((conversation) =>
                conversation.id === newMessage.conversation_id
                  ? {
                      ...conversation,
                      last_message: enrichedMessage.content,
                      last_message_at: enrichedMessage.created_at,
                      unread_count: conversation.unread_count,
                    }
                  : conversation
              )
            : oldConversations
      );

      queryClient.invalidateQueries({ queryKey: ['conversations'] }); // Restored
    },

    onError: (error: Error, _variables, context) => {
      if (context?.previousMessages) {
        queryClient.setQueryData(['messages', context.conversationId], context.previousMessages);
      }

      toast({
        title: 'Error',
        description: `Failed to send message: ${error.message}`,
        variant: 'destructive',
      });
      if (context?.conversationId) {
        queryClient.invalidateQueries({ queryKey: ['messages', context.conversationId] });
      }
    },
  });
}

// Custom hook to update a message
export function useUpdateMessage() {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  return useMutation({
    mutationFn: MessagingService.updateMessage,
    onSuccess: (updatedMessage: Message) => {
      queryClient.invalidateQueries({ queryKey: ['messages', updatedMessage.conversation_id] });
    },
    onError: (error: Error) => {
      toast({
        title: 'Error',
        description: `Failed to update message: ${error.message}`,
        variant: 'destructive',
      });
    },
  });
}

// Custom hook to delete a message
export function useDeleteMessage() {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  return useMutation({
    mutationFn: MessagingService.deleteMessage,
    onSuccess: () => {
      // Invalidate all message queries, or be more specific if conversationId is available
      queryClient.invalidateQueries({ queryKey: ['messages'] });
    },
    onError: (error: Error) => {
      toast({
        title: 'Error',
        description: `Failed to delete message: ${error.message}`,
        variant: 'destructive',
      });
    },
  });
}

// Custom hook to get total unread message count
export function useTotalUnreadMessageCount() {
  return useQuery<number>({
    queryKey: ['totalUnreadMessageCount'],
    queryFn: MessagingService.getTotalUnreadMessageCount,
    refetchInterval: 30000, // Refetch every 30 seconds
  });
}