package domain

import (
	"context"
	"encoding/json"
)

// SearchResult represents a single item in the search results list.
type SearchResult struct {
	Type   string          `json:"type"`   // e.g., "user", "community", "event", "post"
	Rank   float32         `json:"rank"`   // Relevance score from the database
	Result json.RawMessage `json:"result"` // The actual JSON object of the found item
}

// DetailedSearchResult represents a search result with the actual item unmarshaled.
type DetailedSearchResult struct {
	Type   string      `json:"type"`
	Rank   float32     `json:"rank"`
	Data   interface{} `json:"data"` // Can be user_domain.User, community_domain.Community, event_domain.Event, etc.
}

// SearchRepository defines the interface for the search data access layer.
type SearchRepository interface {
	Search(ctx context.Context, query, typeFilter string, limit, offset int) ([]*SearchResult, error)
	SearchUsers(ctx context.Context, query string, limit, offset int) ([]*SearchResult, error)
	SearchCommunities(ctx context.Context, userID, query string, limit, offset int) ([]*SearchResult, error)
	SearchEvents(ctx context.Context, userID, query string, limit, offset int) ([]*SearchResult, error)
}

// SearchService defines the interface for the search business logic.
type SearchService interface {
	Search(ctx context.Context, query, typeFilter string, limit, offset int) ([]*DetailedSearchResult, error)
	SearchUsers(ctx context.Context, query string, limit, offset int) ([]*DetailedSearchResult, error)
	SearchCommunities(ctx context.Context, userID, query string, limit, offset int) ([]*DetailedSearchResult, error)
	SearchEvents(ctx context.Context, userID, query string, limit, offset int) ([]*DetailedSearchResult, error)
}
