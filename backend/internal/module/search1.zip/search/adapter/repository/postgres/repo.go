package postgres

import (
	"context"
	"fmt"
	"strings"
	"unicode"

	"github.com/attendwise/backend/internal/module/search/domain"
	"github.com/jackc/pgx/v5/pgxpool"
)

type searchRepository struct {
	db *pgxpool.Pool
}

func NewSearchRepository(db *pgxpool.Pool) domain.SearchRepository {
	return &searchRepository{db: db}
}

func (r *searchRepository) Search(ctx context.Context, query, typeFilter string, limit, offset int) ([]*domain.SearchResult, error) {
	// Use plainto_tsquery for better handling of multi-word queries
	sqlQuery := `
        WITH search_query AS (SELECT plainto_tsquery('english', $1) AS query)
    `
	var queries []string
	args := []interface{}{query, limit, offset}

	// Search Users
	if typeFilter == "" || typeFilter == "user" {
		queries = append(queries, fmt.Sprintf(`
            SELECT 'user' AS type, ts_rank(to_tsvector('english', name || ' ' || COALESCE(company, '')), query) AS rank, json_build_object('id', id, 'name', name, 'email', email, 'profile_picture_url', profile_picture_url, 'bio', bio, 'company', company, 'position', position, 'location', location) AS result
            FROM users, search_query
            WHERE to_tsvector('english', name || ' ' || COALESCE(company, '')) @@ query
        `))
	}

	// Search Communities
	if typeFilter == "" || typeFilter == "community" {
		queries = append(queries, fmt.Sprintf(`
            SELECT 'community' AS type, ts_rank(to_tsvector('english', name || ' ' || COALESCE(description, '')), query) AS rank, json_build_object('id', id, 'name', name, 'slug', slug, 'description', description, 'cover_image_url', cover_image_url, 'type', type, 'member_count', member_count) AS result
            FROM communities, search_query
            WHERE to_tsvector('english', name || ' ' || COALESCE(description, '')) @@ query
        `))
	}

	// Search Events
	if typeFilter == "" || typeFilter == "event" {
		queries = append(queries, fmt.Sprintf(`
            SELECT 'event' AS type, ts_rank(to_tsvector('english', name || ' ' || COALESCE(description, '')), query) AS rank, json_build_object('id', id, 'name', name, 'slug', slug, 'description', description, 'cover_image_url', cover_image_url, 'start_time', start_time, 'location_type', location_type, 'location_address', location_address) AS result
            FROM events, search_query
            WHERE to_tsvector('english', name || ' ' || COALESCE(description, '')) @@ query
        `))
	}

	// Search Posts
	if typeFilter == "" || typeFilter == "post" {
		queries = append(queries, fmt.Sprintf(`
            SELECT 'post' AS type, ts_rank(to_tsvector('english', content), query) AS rank, json_build_object('id', id, 'content', LEFT(content, 200), 'community_id', community_id, 'created_at', created_at) AS result
            FROM posts, search_query
            WHERE to_tsvector('english', content) @@ query AND status = 'approved'
        `))
	}

	if len(queries) == 0 {
		return []*domain.SearchResult{}, nil
	}

	// Combine all queries with UNION ALL
	fullQuery := sqlQuery + " " + queries[0]
	for i := 1; i < len(queries); i++ {
		fullQuery += " UNION ALL " + queries[i]
	}

	// Add ordering and pagination
	fullQuery += " ORDER BY rank DESC LIMIT $2 OFFSET $3"

	rows, err := r.db.Query(ctx, fullQuery, args...)
	if err != nil {
		return nil, fmt.Errorf("failed to execute search query: %w", err)
	}
	defer rows.Close()

	results := make([]*domain.SearchResult, 0)
	for rows.Next() {
		var res domain.SearchResult
		if err := rows.Scan(&res.Type, &res.Rank, &res.Result); err != nil {
			return nil, fmt.Errorf("failed to scan search result: %w", err)
		}
		results = append(results, &res)
	}

	return results, nil
}

func (r *searchRepository) SearchUsers(ctx context.Context, query string, limit, offset int) ([]*domain.SearchResult, error) {
	sqlQuery := `
        SELECT 'user' AS type, ts_rank(to_tsvector('english', name || ' ' || COALESCE(company, '')), query) AS rank, json_build_object('id', id, 'name', name, 'email', email, 'profile_picture_url', profile_picture_url, 'bio', bio, 'company', company, 'position', position, 'location', location) AS result
        FROM users, plainto_tsquery('english', $1) AS query
        WHERE to_tsvector('english', name || ' ' || COALESCE(company, '')) @@ query
        ORDER BY rank DESC
        LIMIT $2 OFFSET $3
    `
	rows, err := r.db.Query(ctx, sqlQuery, query, limit, offset)
	if err != nil {
		return nil, fmt.Errorf("failed to execute search users query: %w", err)
	}
	defer rows.Close()

	results := make([]*domain.SearchResult, 0)
	for rows.Next() {
		var res domain.SearchResult
		if err := rows.Scan(&res.Type, &res.Rank, &res.Result); err != nil {
			return nil, fmt.Errorf("failed to scan search result: %w", err)
		}
		results = append(results, &res)
	}

	return results, nil
}

func (r *searchRepository) SearchCommunities(ctx context.Context, userID, query string, limit, offset int) ([]*domain.SearchResult, error) {
	normalized := strings.ToLower(strings.TrimSpace(query))
	if normalized == "" {
		return []*domain.SearchResult{}, nil
	}

	tsQuery := buildPrefixTsQuery(normalized)

	// For very short or non-alphanumeric queries the full text index ignores the term.
	// Fallback to a case-insensitive LIKE matcher so users still see results.
	if len([]rune(normalized)) < 3 || tsQuery == "" {
		likePattern := "%" + normalized + "%"
		sqlQuery := `
			SELECT 'community' AS type,
			       1.0 AS rank,
			       json_build_object('id', c.id,
			                           'name', c.name,
			                           'slug', c.slug,
			                           'cover_image_url', c.cover_image_url,
			                           'member_count', c.member_count) AS result
			FROM communities c
			LEFT JOIN community_members cm ON c.id = cm.community_id AND cm.user_id = $1
			WHERE c.deleted_at IS NULL
			  AND (c.type = 'public'
			       OR c.type = 'private'
			       OR (c.type = 'secret' AND cm.user_id IS NOT NULL AND cm.status = 'active'))
			  AND (LOWER(c.name) LIKE $2 OR LOWER(COALESCE(c.description, '')) LIKE $2)
			ORDER BY LOWER(c.name) ASC
			LIMIT $3 OFFSET $4
		`
		rows, err := r.db.Query(ctx, sqlQuery, userID, likePattern, limit, offset)
		if err != nil {
			return nil, fmt.Errorf("failed to execute fallback community search: %w", err)
		}
		defer rows.Close()

		results := make([]*domain.SearchResult, 0)
		for rows.Next() {
			var res domain.SearchResult
			if err := rows.Scan(&res.Type, &res.Rank, &res.Result); err != nil {
				return nil, fmt.Errorf("failed to scan fallback community search result: %w", err)
			}
			results = append(results, &res)
		}
		return results, nil
	}

	likePattern := "%" + normalized + "%"
	sqlQuery := `
		WITH search_query AS (SELECT to_tsquery('english', $1) AS query)
		SELECT 'community' AS type,
		       (
					CASE
						WHEN search_query.query <> ''::tsquery
						 AND to_tsvector('english', c.name || ' ' || COALESCE(c.description, '')) @@ search_query.query
						THEN ts_rank(to_tsvector('english', c.name || ' ' || COALESCE(c.description, '')), search_query.query)
						ELSE 0
					END
					+
					CASE WHEN LOWER(c.name) LIKE $5 THEN 0.2 ELSE 0 END
					+
					CASE WHEN LOWER(COALESCE(c.description, '')) LIKE $5 THEN 0.1 ELSE 0 END
				) AS rank,
		       json_build_object('id', id,
		                           'name', name,
		                           'slug', slug,
		                           'cover_image_url', cover_image_url,
		                           'member_count', member_count) AS result
		FROM communities c
		LEFT JOIN community_members cm ON c.id = cm.community_id AND cm.user_id = $2,
		     search_query
		WHERE c.deleted_at IS NULL
		  AND (c.type = 'public'
		       OR c.type = 'private'
		       OR (c.type = 'secret' AND cm.user_id IS NOT NULL AND cm.status = 'active'))
		  AND (
				(search_query.query <> ''::tsquery
				 AND to_tsvector('english', c.name || ' ' || COALESCE(c.description, '')) @@ search_query.query)
				OR LOWER(c.name) LIKE $5
				OR LOWER(COALESCE(c.description, '')) LIKE $5
		  )
		ORDER BY rank DESC
		LIMIT $3 OFFSET $4
	`
	rows, err := r.db.Query(ctx, sqlQuery, tsQuery, userID, limit, offset, likePattern)
	if err != nil {
		return nil, fmt.Errorf("failed to execute search communities query: %w", err)
	}
	defer rows.Close()

	results := make([]*domain.SearchResult, 0)
	for rows.Next() {
		var res domain.SearchResult
		if err := rows.Scan(&res.Type, &res.Rank, &res.Result); err != nil {
			return nil, fmt.Errorf("failed to scan search result: %w", err)
		}
		results = append(results, &res)
	}

	return results, nil
}

func (r *searchRepository) SearchEvents(ctx context.Context, userID, query string, limit, offset int) ([]*domain.SearchResult, error) {
	sqlQuery := `
		SELECT 'event' AS type, ts_rank(to_tsvector('english', e.name || ' ' || COALESCE(e.description, '')), query) AS rank, json_build_object('id', e.id, 'name', e.name, 'slug', e.slug, 'cover_image_url', e.cover_image_url, 'start_time', e.start_time) AS result
		FROM events e
		JOIN community_members cm ON e.community_id = cm.community_id,
		     plainto_tsquery('english', $1) AS query
		WHERE cm.user_id = $2 AND to_tsvector('english', e.name || ' ' || COALESCE(e.description, '')) @@ query
		ORDER BY rank DESC
		LIMIT $3 OFFSET $4
	`
	rows, err := r.db.Query(ctx, sqlQuery, query, userID, limit, offset)
	if err != nil {
		return nil, fmt.Errorf("failed to execute search events query: %w", err)
	}
	defer rows.Close()

	var results []*domain.SearchResult
	for rows.Next() {
		var res domain.SearchResult
		if err := rows.Scan(&res.Type, &res.Rank, &res.Result); err != nil {
			return nil, fmt.Errorf("failed to scan search result: %w", err)
		}
		results = append(results, &res)
	}

	return results, nil
}

func buildPrefixTsQuery(input string) string {
	terms := strings.FieldsFunc(input, func(r rune) bool {
		return !unicode.IsLetter(r) && !unicode.IsDigit(r)
	})

	if len(terms) == 0 {
		return ""
	}

	var parts []string
	for _, term := range terms {
		var builder strings.Builder
		for _, r := range strings.ToLower(term) {
			if unicode.IsLetter(r) || unicode.IsDigit(r) {
				builder.WriteRune(r)
			}
		}
		clean := builder.String()
		if clean == "" {
			continue
		}
		parts = append(parts, clean+":*")
	}

	return strings.Join(parts, " & ")
}
