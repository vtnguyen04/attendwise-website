package usecase

import (
	"context"
	"encoding/json"
	"strings"

	community_domain "github.com/attendwise/backend/internal/module/community/domain"
	event_domain "github.com/attendwise/backend/internal/module/event/domain"
	"github.com/attendwise/backend/internal/module/search/domain"
	user_domain "github.com/attendwise/backend/internal/module/user/domain"
)

type searchService struct {
	repo domain.SearchRepository
}

func NewSearchService(repo domain.SearchRepository) domain.SearchService {
	return &searchService{repo: repo}
}

func (s *searchService) Search(ctx context.Context, query, typeFilter string, limit, offset int) ([]*domain.DetailedSearchResult, error) {
	// Sanitize query
	cleanQuery := strings.TrimSpace(query)
	if cleanQuery == "" {
		return []*domain.DetailedSearchResult{}, nil
	}

	results, err := s.repo.Search(ctx, cleanQuery, typeFilter, limit, offset)
	if err != nil {
		return nil, err
	}

	detailedResults := make([]*domain.DetailedSearchResult, 0, len(results))
	for _, res := range results {
		detailedRes := &domain.DetailedSearchResult{
			Type: res.Type,
			Rank: res.Rank,
		}

		switch res.Type {
		case "user":
			var user user_domain.User
			if err := json.Unmarshal(res.Result, &user); err != nil {
				// Log error, decide how to handle (skip, return error, etc.)
				continue
			}
			detailedRes.Data = user
		case "community":
			var community community_domain.Community
			if err := json.Unmarshal(res.Result, &community); err != nil {
				// Log error
				continue
			}
			detailedRes.Data = community
		case "event":
			var event event_domain.Event
			if err := json.Unmarshal(res.Result, &event); err != nil {
				// Log error
				continue
			}
			detailedRes.Data = event
		// Add other types like "post" here if needed
		default:
			// Handle unknown types or just include the raw message
			detailedRes.Data = res.Result
		}
		detailedResults = append(detailedResults, detailedRes)
	}

	return detailedResults, nil
}

func (s *searchService) SearchUsers(ctx context.Context, query string, limit, offset int) ([]*domain.DetailedSearchResult, error) {
	cleanQuery := strings.TrimSpace(query)
	if cleanQuery == "" {
		return []*domain.DetailedSearchResult{}, nil
	}
	results, err := s.repo.SearchUsers(ctx, cleanQuery, limit, offset)
	if err != nil {
		return nil, err
	}

	detailedResults := make([]*domain.DetailedSearchResult, 0, len(results))
	for _, res := range results {
		detailedRes := &domain.DetailedSearchResult{
			Type: res.Type,
			Rank: res.Rank,
		}
		var user user_domain.User
		if err := json.Unmarshal(res.Result, &user); err != nil {
			continue
		}
		detailedRes.Data = user
		detailedResults = append(detailedResults, detailedRes)
	}
	return detailedResults, nil
}

func (s *searchService) SearchCommunities(ctx context.Context, userID, query string, limit, offset int) ([]*domain.DetailedSearchResult, error) {
	cleanQuery := strings.TrimSpace(query)
	if cleanQuery == "" {
		return []*domain.DetailedSearchResult{}, nil
	}
	results, err := s.repo.SearchCommunities(ctx, userID, cleanQuery, limit, offset)
	if err != nil {
		return nil, err
	}

	detailedResults := make([]*domain.DetailedSearchResult, 0, len(results))
	for _, res := range results {
		detailedRes := &domain.DetailedSearchResult{
			Type: res.Type,
			Rank: res.Rank,
		}
		var community community_domain.Community
		if err := json.Unmarshal(res.Result, &community); err != nil {
			continue
		}
		detailedRes.Data = community
		detailedResults = append(detailedResults, detailedRes)
	}
	return detailedResults, nil
}

func (s *searchService) SearchEvents(ctx context.Context, userID, query string, limit, offset int) ([]*domain.DetailedSearchResult, error) {
	cleanQuery := strings.TrimSpace(query)
	if cleanQuery == "" {
		return []*domain.DetailedSearchResult{}, nil
	}
	results, err := s.repo.SearchEvents(ctx, userID, cleanQuery, limit, offset)
	if err != nil {
		return nil, err
	}

	detailedResults := make([]*domain.DetailedSearchResult, 0, len(results))
	for _, res := range results {
		detailedRes := &domain.DetailedSearchResult{
			Type: res.Type,
			Rank: res.Rank,
		}
		var event event_domain.Event
		if err := json.Unmarshal(res.Result, &event); err != nil {
			continue
		}
		detailedRes.Data = event
		detailedResults = append(detailedResults, detailedRes)
	}
	return detailedResults, nil
}
